<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>PHP Class 02</title>
	</head>
	<body>


		<?php 

			//Nested If Statement

			/*

			if(con1){
				//Con True;
				if(con2){
					///con True
				}
			}

			*/


			//Applying Vote

			$nationality = "Bangladesh";
			$age = 17;

			if($nationality == "Bangladesh"){
				if($age>=18){
					echo "Elgible to give vote";
				}else{
					echo "Not Elgible to give vote";
				}
			}

			echo "<br>";


			//Switch 

			$num = 1999;

			switch($num){
				case 1990:
				echo("Number is equal to 1990");

				break;
				case 1991:
				echo("Number is equal to 1991"); 

				break;
				case 1992:
				echo("Number is equal to 1992");

				break;
				case 1993:
				echo("Number is equal to 1993");

				break;
				case 1994:
				echo("Number is equal to 1994");

				break;
				default:
				echo("Number is Not equal to 1990,1991,1992,1993,1994");
			}


			echo "<br>";


			$ch= 'a';

			switch($ch){
				case 'A':
					echo "Given Character is Vowel";
					break;

				case 'E':
					echo "Given Character is Vowel";
					break;

				case 'I':
					echo "Given Character is Vowel";
					break;

				case 'O':
					echo "Given Character is Vowel";
					break;

				case 'U':
					echo "Given Character is Vowel";
					break;

				case 'a':
					echo "Given Character is Vowel";
					break;

				case 'e':
					echo "Given Character is Vowel";
					break;

				case 'i':
					echo "Given Character is Vowel";
					break;

				case 'o':
					echo "Given Character is Vowel";
					break;

				case 'u':
					echo "Given Character is Vowel";
					break;

				default:
					echo "Given Character is Consonent";
					break;
			}

			echo "<br>";

			//Nested Switch


			$car = "BMW";
			$model = "Boom";

			switch($car){
				case "Toyta":
				switch($model){
					case "Cool":
					echo "Toyta Cool Price is 25.3L - 29.5Lakh";
					break;

					case "boom":
					echo "Toyta Boom Price is 35.3L - 39.5Lakh";
					break;

					case "Boom & Cool":
					echo "Toyta Boom & Cool Price is 55.3L - 59.5Lakh";
					break;
				}

				break;

				case "BMW":
					switch($model){
						case "Cool":
						echo "BMW Cool Price is 85.5L - 100.9Lakh";
						break;

						case "Boom":
						echo "BMW Boom Price is 95.5L - 115.5Lakh";
						break;

						case "Boom & Cool":
						echo "BMW Boom & Cool Price is 135.5L - 165.5Lakh";
						break;
					}
				break;
			}



			//For Loop

			

			for($aa = 30; $aa>=15; $aa--){
				echo "$aa <br>";
			}

			echo "<br>";

			//Infinite Loop 01

			for($s=5;;$s++){
				if($s>10){
					break;
				}
				echo $s;
			}
			echo "<br>";

			//Infinite Loop 02

			$x = 93;
			for(;;){
				if($x>110){
					break;
				}
				echo $x;
				$x++;
			}
			echo "<br>";


			//Nested For Loop

			for($q=1; $q<=10; $q++){
				for($w=1;$w<=5; $w++){
					echo "$q $w <br>";
				}
			}


			//Dectar Array

			$season = array("Summer", "Winter", "Spring","Autumn");

			//Access array Element Foreach Loop

			foreach($season as $element){
				echo "$element";
				echo "<br>";
			}

			//Dectar Array 02

			$employee = array(

				"Name" => "MRH Jewel",
				"Email" => "mrh@gmail.com",
				"age" => 31,
				"Dist" => "Chandpur"

			);

			//Display Associative array elemments foreach loop

			foreach($employee as $key => $element){
				echo $key .":".$element;
				echo "<br>";
			}
























		?>




	</body>
</html>

