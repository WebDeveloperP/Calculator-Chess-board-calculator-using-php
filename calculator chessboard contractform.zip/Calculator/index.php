<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Calculator Program In PHP</title>
	</head>
	<body>

		<?php 

			$first_num = $_POST['first_num'];
			$secound_num = $_POST['secound_num'];
			$operator = $_POST['operator'];
			$result = '';


			if(is_numeric($first_num) && is_numeric($secound_num)){
				switch($operator){
					case "Add":
						$result = $first_num + $secound_num;
						break;
					case "Subtract":
						$result = $first_num - $secound_num;
						break;
					case "Multiply":
						$result = $first_num * $secound_num;
						break;
					case "Divide":
						$result = $first_num / $secound_num;
					
				}
			}



		?>




		<div id="page_wrap">
			
			<h1>Calculator Using PHP</h1>


			<form action="" method="post" id="quiz-form">
				

				<p>
					<input type="number" name="first_num" id="first_num" required="required" value="<?php echo $first_num; ?>" >

					<strong>First Number</strong>
				</p>

				<p>
					<input type="number" name="secound_num" id="secound_num" required="required" value="<?php echo $secound_num; ?>" >

					<strong>Secound Number</strong>
				</p>

				<p>
					<input readonly="readonly" name="result" value="<?php echo $result; ?>" >

					<strong>Result</strong>
				</p>

				<input type="submit" name="operator" value="Add">
				<input type="submit" name="operator" value="Subtract">
				<input type="submit" name="operator" value="Multiply">
				<input type="submit" name="operator" value="Divide">


			</form>


		</div>








	</body>
</html>