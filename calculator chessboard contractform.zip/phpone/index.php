<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>PHP Class 01</title>
	</head>
	<body>


		<h1>Hello World!</h1>

		<?php 

			echo "Hello PHP World!";

			echo "<h1>Hello PHP World!</h1>";

			echo 1993;

			echo "<br>";



			$murad = 500;
			$rabiul = 12;
			$total =  $murad +  $rabiul;

			echo $total;

			echo "<br>";


			$aa = 10;
			$bb = 100;
			$cc = 1000;
			$dd = 10000;
			$ee = 100000;
			$ff = 1000000;
			$gg = 10000000;

			echo $aa*$bb*$cc*$dd;


			echo "<br>";


			$as = 1000;
			var_dump($as);

			echo "<br>";

			$asd = "Hello PHP";
			var_dump($asd);

			echo "<br>";

			$asdf = 4.94;
			var_dump($asdf);

			echo "<br>";

			$asw = "1993";
			var_dump($asw);


			echo "<br>";

			$qw = 15;
			if($qw < 20){
				echo $qw;
			}

			$zz = 1090;
			$sz = 890;

			if($zz > $sz){
				echo "zz is bigger";
			}else{
				echo "sz is smaller";
			}

			echo "<br>";

			//If Statment


			$boom = 55;

			if($boom < 500){
				echo "$boom is less then 500";
			}

			//If else  Statment

			/*
			if(condition){
				//true
			}else{
				//false
			}
			*/

			echo "<br>";

			$cool = 8859;

			if($cool%2==1){
				echo "$cool Is Odd Number";
			}else{
				echo "$cool Is Even Number";
			}


			//If else if  Statment


			/*if(condition){
				//excuted condition 01 true
			}elseif(condition2){
				//excuted condition 02 true
			}elseif(condition3){
				//excuted condition 03 true
			}elseif(condition4){
				//excuted condition 04 true
			}elseif(condition5){
				//excuted condition 05 true
			}elseif(condition6){
				//excuted conition 06 true
			}elseif(condition7){
				//excuted condition 07 true
			}elseif(condition2){
				//excuted condition 02 true
			}else{
				//excuted condition is fals
			}*/



			echo "<br>";




			$mark = 32;

			if($mark < 33){
				echo "Fail";
			}elseif($mark>=33 && $mark<40){
				echo "D Grade";
			}elseif($mark>=40 && $mark<50){
				echo "C Grade";
			}elseif($mark>=50 && $mark<60){
				echo "B Grade";
			}elseif($mark>=60 && $mark<70){
				echo "A- Grade";
			}elseif($mark>=70 && $mark<80){
				echo "A Grade";
			}elseif($mark>=80 && $mark<90){
				echo "A+ Grade";
			}elseif($mark>=90 && $mark<100){
				echo "Star Mark";
			}else{
				echo "Invalid Input";
			}





















			echo "<br>";
			echo "<br>";
			echo "<br>";
			echo "<br>";
			echo "<br>";
			echo "<br>";

			echo "<br>";
			echo "<br>";
			echo "<br>";

			echo "<br>";
			echo "<br>";
			echo "<br>";

		?>






	</body>
</html>