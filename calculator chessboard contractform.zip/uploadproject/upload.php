
<?php

	$target_path = "e:/";

	$target_path = $target_path.basename($_FILES['fileUpload'] ['name']);

	if(move_uploaded_file($_FILES['fileUpload'] ['tmp_name'], $target_path)){
		echo "File Upload Successfully";
	}else{
		echo " Sorry, File Not Uploaded , please Try again!";
	}

?>