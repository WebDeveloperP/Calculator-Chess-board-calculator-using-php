<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>PHP Class 03</title>
	</head>
	<body>


		<?php 

			//Dynamic Array

			foreach(array('f','r','e','e','d','o','m') as $elements){
				echo "$elements\n";
			}

			//While Loop 01

			echo "<br>";
			echo "<br>";

			$a = 1;

			while($a<=5){
				echo "$a <br>";
				$a++;
			}

			//While Loop 02

			echo "<br>";
			echo "<br>";


			$aa = 5;

			while($aa<=10):
				echo "$aa <br>";
				$aa++;
			endwhile;


			echo "<br>";
			echo "<br>";

			//PHP Function

			function fname(){
				echo "Hello World!";
			}
			fname(); //Calling Function


			echo "<br>";

			//PHP Function 2

			function sayName($name){
				echo "Hello $name <br>";
			}
			sayName("MRH Jewel");
			sayName("Siful");
			sayName("Kamal");
			sayName("Ershad");
			sayName("Nazmul");
			sayName("Junaied");

			echo "<br>";

			//PHP Function 3

			function sayNameAge($name,$age){
				echo "Hello $name You are $age years Old <br>";
			}
			sayNameAge("Rabiul", 31);
			sayNameAge("Zakir", 45);
			sayNameAge("Bazlur", 55);
			sayNameAge("Ilias", 42);

			echo "<br>";

			//PHP Call Reference 04

			function cool(&$cbr){
				$cbr .= 'Call By Reference <br>';
			}
			$cbr1= "Hello ";
			cool($cbr1);
			echo $cbr1;


			echo "<br>";

			//PHP Function Argument Value 05

			function boom( $aaa = "Ayesha"){
				echo " Hello $aaa";
			}
			boom("Rabiul");
			boom(); //No Value
			boom("Hossain");

			echo "<br>";
			echo "<br>";

			// PHP Function Returning Value

			function rv($t){
				return $t*$t*$t;
			}
			echo " Return of 10 is " . rv(10);


			echo "<br>";
			echo "<br>";



			//Associative Array 02


			$salary["Jewel"]= "70000";
			$salary["Muslim"]= "80000";
			$salary["Kamal"]= "45000";
			$salary["Zamal"]= "95000";

			echo "Jewel Salary : ".$salary["Jewel"]."<br>";
			echo "Muslim Salary : ".$salary["Muslim"]."<br>";
			echo "Kamal Salary : ".$salary["Kamal"]."<br>";
			echo "Zamal Salary : ".$salary["Zamal"]."<br>";






		?>

		







		<br>
		<br>
		<br>
		<br>
		<br>
		<br>

	</body>
</html>

